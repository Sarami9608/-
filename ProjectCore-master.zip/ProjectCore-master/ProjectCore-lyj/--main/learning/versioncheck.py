import sklearn
import numpy as np
import pandas as pd

print("scikit-learn version:", sklearn.__version__)
print("numpy version:", np.__version__)
print("pandas version:", pd.__version__)